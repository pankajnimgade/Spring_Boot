package com.external.db.jpa.external.db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExternalDataBaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExternalDataBaseApplication.class, args);
	}
}
